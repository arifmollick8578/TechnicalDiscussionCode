package com.mollick.interviewproject

import android.app.Application

//class UserApplication: Application()
